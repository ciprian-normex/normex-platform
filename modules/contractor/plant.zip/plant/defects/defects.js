import { auth, db } from "/js/firebase.js";
import { collection, doc, getDocs, query, runTransaction, serverTimestamp, where } from "https://www.gstatic.com/firebasejs/12.2.1/firebase-firestore.js";
import { initialisePlantShell } from "/modules/contractor/plant/shared/plant-shell.js";
import { escapePlantHtml as esc, formatPlantDateTime as dateTime } from "/modules/contractor/plant/shared/plant-utils.js";
const $=id=>document.getElementById(id), clean=v=>String(v??"").trim(), omit=o=>Object.fromEntries(Object.entries(o).filter(([,v])=>v!==undefined));
const STATUSES=["REPORTED","ACKNOWLEDGED","AWAITING_ATTENDANCE","AWAITING_PARTS","REPAIR_IN_PROGRESS","REPLACEMENT_REQUESTED","AWAITING_REPLACEMENT","REPAIR_COMPLETE","AWAITING_RTS","CLOSED"], legacy={OPEN:"REPORTED",ASSESSED:"ACKNOWLEDGED",AWAITING_RETURN_TO_SERVICE:"AWAITING_RTS"};
let profile,org,assets=[],defects=[],suppliers=[],selectedCase=null,saving=false; const normal=v=>legacy[v]||v, label=v=>clean(v).replaceAll("_"," ").toLowerCase().replace(/\b\w/g,c=>c.toUpperCase()), active=d=>normal(d.status)!=="CLOSED";
function manage(p,r={organisationId:org}){const b={WORKER:0,SUPERVISOR:1,SITE_MANAGER:2,PROJECT_MANAGER:3,SENIOR_PROJECT_MANAGER:4,HEALTH_SAFETY:4.5,SENIOR_HEALTH_SAFETY:4.6,CONTRACTS_MANAGER:5,PLANT_TRANSPORT_MANAGER:5.5,ORGANISATION_MANAGER:6,PLATFORM_ADMIN:99},platform=p?.status==="ACTIVE"&&p.organisationId===org&&r.organisationId===org&&p.roleCode==="PLATFORM_ADMIN"&&p.accessLevel===99;return !!(platform||(p?.status==="ACTIVE"&&p.organisationId===org&&r.organisationId===org&&p.permissions&&b[p.roleCode]===p.accessLevel&&(["PLANT_TRANSPORT_MANAGER"].includes(p.roleCode)||p.permissions.canManagePlant||p.permissions.canManageOrganisation)));}
function reporter(p){const b={WORKER:0,SUPERVISOR:1,SITE_MANAGER:2,PROJECT_MANAGER:3,SENIOR_PROJECT_MANAGER:4,HEALTH_SAFETY:4.5,SENIOR_HEALTH_SAFETY:4.6,CONTRACTS_MANAGER:5,PLANT_TRANSPORT_MANAGER:5.5,ORGANISATION_MANAGER:6,PLATFORM_ADMIN:99},level=b[p?.roleCode];return !!(p?.status==="ACTIVE"&&p.organisationId===org&&Number.isFinite(level)&&level>=1&&p.accessLevel===level);}
function valid(a,b){const n={REPORTED:["ACKNOWLEDGED"],ACKNOWLEDGED:["AWAITING_ATTENDANCE","AWAITING_PARTS","REPAIR_IN_PROGRESS"],AWAITING_ATTENDANCE:["AWAITING_PARTS","REPAIR_IN_PROGRESS"],AWAITING_PARTS:["REPAIR_IN_PROGRESS","REPLACEMENT_REQUESTED"],REPAIR_IN_PROGRESS:["REPAIR_COMPLETE","AWAITING_RTS"],REPLACEMENT_REQUESTED:["AWAITING_REPLACEMENT"],AWAITING_REPLACEMENT:["REPAIR_COMPLETE"],REPAIR_COMPLETE:["AWAITING_RTS"],AWAITING_RTS:["CLOSED"]};return !!n[normal(a)]?.includes(b);}
function assetPatch(d,a,uid,ts){return d.operationalHold?omit({safeToUse:false,offRoad:true,status:"OFF_ROAD",defectOwnedRestriction:true,updatedByUid:uid,updatedByName:clean(a.displayName)||null,updatedAt:ts}):{};}
function returnPatch(a,p,u,uid,ts){if(a.complianceHold)return {status:"COMPLIANCE_HOLD",updatedByUid:uid,updatedByName:clean(u.displayName)||null,updatedAt:ts};return omit({safeToUse:p?.safeToUse,offRoad:p?.offRoad,status:p?.status,updatedByUid:uid,updatedByName:clean(u.displayName)||null,updatedAt:ts});}
const asset=id=>assets.find(a=>a.id===id), aName=a=>[a?.plantReference||a?.plantId||a?.id,[a?.manufacturer,a?.model].filter(Boolean).join(" "),a?.plantType||a?.capacity].filter(Boolean).join(" · ");
async function load(n){const s=await getDocs(query(collection(db,n),where("organisationId","==",org)));return s.docs.map(x=>({...x.data(),id:x.id}));}
async function init(p){profile=p;org=p?.organisationId;initialisePlantShell({activePage:"defects",workspaceName:"Fleet & Transport Control"});if(!org){$("defectStatus").textContent="Unavailable: organisation context is missing.";return;}$("reportDefect").hidden=!reporter(p);bind();await reload();}
async function reload(){try{[assets,defects,suppliers]=await Promise.all([load("plantAssets"),load("plantDefects"),load("plantSuppliers").catch(()=>[])]);$("defectStatus").textContent=manage(profile)?"Repair control ready.":reporter(profile)?"Report faults and view repair control.":"Defects unavailable.";render();}catch(e){$("defectStatus").textContent="Defect data unavailable.";$("defectRegister").innerHTML="<div class=\"defect-empty\">Defect data unavailable.</div>";}}
function render(){const open=defects.filter(active),held=open.filter(d=>d.operationalHold),awaiting=open.filter(d=>["AWAITING_ATTENDANCE","AWAITING_PARTS","REPLACEMENT_REQUESTED","AWAITING_REPLACEMENT"].includes(normal(d.status))),repair=open.filter(d=>normal(d.status)==="REPAIR_IN_PROGRESS"),rts=open.filter(d=>normal(d.status)==="AWAITING_RTS");const values=[open.filter(d=>["REPORTED","ACKNOWLEDGED"].includes(normal(d.status))).length,held.length,awaiting.length,repair.length,rts.length];document.querySelectorAll("#defectSummary .position-tile").forEach((tile,i)=>{const value=tile.querySelector(".position-value");if(value)value.textContent=values[i];tile.dataset.filter=["reported","out","awaiting","repair","rts"][i];tile.classList.toggle("is-selected",summaryFilter==tile.dataset.filter);});const s=$("defectAssetSelect"),keep=s.value;s.innerHTML='<option value="">Select Plant asset</option>'+assets.map(a=>`<option value="${esc(a.id)}">${esc(aName(a))}</option>`).join("");s.value=keep;populateFilterOptions();renderActive(open);renderRegister();renderCharts(open);renderDonut(open);$("defectCount").textContent=`${defects.length} recorded defect${defects.length===1?"":"s"}`;}
let summaryFilter="", donutFilter="";
function summaryMatches(d){const st=normal(d.status);return !summaryFilter||(summaryFilter==="reported"?["REPORTED","ACKNOWLEDGED"].includes(st):summaryFilter==="out"&&d.operationalHold||summaryFilter==="awaiting"&&["AWAITING_ATTENDANCE","AWAITING_PARTS","REPLACEMENT_REQUESTED","AWAITING_REPLACEMENT"].includes(st)||summaryFilter==="repair"&&st==="REPAIR_IN_PROGRESS"||summaryFilter==="rts"&&st==="AWAITING_RTS");}
function populateFilterOptions(){const put=(id,vals)=>{const e=$(id);if(!e)return;const keep=e.value;e.innerHTML='<option value="">'+(id==="defectStatusFilter"?"All statuses":id==="defectImpactFilter"?"All positions":id==="defectSupplierFilter"?"All suppliers":"All projects")+'</option>'+[...new Set(vals.filter(Boolean))].map(v=>`<option value="${esc(v)}">${esc(label(v))}</option>`).join("");e.value=keep;};put("defectStatusFilter",STATUSES);put("defectImpactFilter",defects.map(d=>d.operationalPosition));put("defectSupplierFilter",defects.map(d=>d.repairSupplier));put("defectProjectFilter",defects.map(d=>d.currentProjectId));}function renderActive(rows){const box=$("activeCases"),items=rows.filter(summaryMatches).filter(d=>!donutFilter||donutGroup(d)===donutFilter);box.innerHTML=items.length?items.map(d=>{const a=asset(d.assetId),u=(d.caseUpdates||[]).slice(-1)[0],critical=d.operationalHold||d.workImpact==="STOPPED";return `<article class="repair-row ${critical?"repair-row--critical":""}"><div class="repair-priority"><span class="priority-marker ${critical?"priority-marker--red":"priority-marker--amber"}"></span><span>${critical?"High":"Monitor"}</span></div><div class="repair-asset"><a href="/modules/contractor/plant/asset/index.html?id=${encodeURIComponent(d.assetId)}" class="repair-asset-id">${esc(d.plantReference||d.plantId)}</a><strong>${esc([a?.manufacturer,a?.model].filter(Boolean).join(" ")||"Plant")}</strong><span>${esc(a?.plantType||a?.capacity||"Plant asset")}</span></div><div class="repair-problem"><strong>${esc(d.description||"Defect")}</strong><div class="repair-badges"><span class="status-pill ${critical?"status-pill--red":"status-pill--blue"}">${esc(label(d.operationalPosition||"Restricted"))}</span><span class="status-pill status-pill--amber">${esc(label(normal(d.status)))}</span></div></div><div class="repair-context"><span class="repair-context-label">Supplier</span><strong>${esc(d.repairSupplier||"Not recorded")}</strong><span>Owner: ${esc(d.responsibleName||"Unassigned")}</span></div><div class="repair-impact"><span class="repair-context-label">${d.workImpact==="STOPPED"?"Downtime":"Restricted"}</span><strong>${esc(duration(d))}</strong><span>${esc(u?.note||"No update")}</span></div><button class="table-open-button" type="button" data-case="${d.id}">Open Case</button></article>`;}).join(""):"<p class=\"defect-note\">No active repair cases.</p>";}
function duration(d){if(!d.downtimeStartedAt||d.workImpact!=="STOPPED")return "Not full downtime";const end=d.repairCompletedAt?new Date(d.repairCompletedAt):new Date(),h=Math.max(0,(end-new Date(d.downtimeStartedAt))/36e5);return h<24?`${Math.round(h)}h`:`${Math.floor(h/24)}d ${Math.round(h%24)}h`;}
function donutGroup(d){const s=normal(d.status);return ["REPORTED","ACKNOWLEDGED"].includes(s)?"reported":["AWAITING_ATTENDANCE","AWAITING_PARTS","REPLACEMENT_REQUESTED","AWAITING_REPLACEMENT"].includes(s)?"awaiting":s==="REPAIR_IN_PROGRESS"?"repair":s==="AWAITING_RTS"?"rts":"";}function renderCharts(r){const c=$("downtimeChart");if(c)c.innerHTML="<p class=\"defect-note\">"+(r.some(d=>d.downtimeStartedAt&&d.workImpact==="STOPPED")?"Rolling 30-day downtime recorded.":"No recorded full downtime in the last 30 days.")+"</p>";}
function renderRegister(){const q=clean($("defectSearch")?.value).toLowerCase(),status=clean($("defectStatusFilter")?.value),impact=clean($("defectImpactFilter")?.value),supplier=clean($("defectSupplierFilter")?.value),project=clean($("defectProjectFilter")?.value);const rows=defects.filter(d=>(!q||[d.plantReference,d.plantId,d.description,d.repairSupplier,d.currentProjectName].join(" ").toLowerCase().includes(q))&&(!status||normal(d.status)===status)&&(!impact||d.operationalPosition===impact)&&(!supplier||d.repairSupplier===supplier)&&(!project||d.currentProjectId===project)&&summaryMatches(d)&&(!donutFilter||donutGroup(d)===donutFilter));const host=$("defectRegister");const table=document.createElement("table");table.className="defect-register-table";table.innerHTML="<thead><tr><th>Plant / defect</th><th>Operational position</th><th>Repair status</th><th>Project / location</th><th>Owner</th><th>Downtime</th><th>Latest update</th><th></th></tr></thead><tbody></tbody>";const body=table.querySelector("tbody");rows.forEach(d=>{const a=asset(d.assetId),u=(d.caseUpdates||[]).slice(-1)[0],tr=document.createElement("tr");tr.innerHTML=`<td><a class="table-plant-id" href="/modules/contractor/plant/asset/index.html?id=${encodeURIComponent(d.assetId)}">${esc(d.plantReference||d.plantId||"Plant")}</a><strong>${esc(d.description||"Defect")}</strong><span>${esc([a?.manufacturer,a?.model].filter(Boolean).join(" ")||"Plant asset")}</span></td><td><span class="status-pill ${d.operationalHold?"status-pill--red":"status-pill--blue"}">${esc(label(d.operationalPosition||"Restricted"))}</span></td><td><strong>${esc(label(normal(d.status)))}</strong><span>${esc(d.repairSupplier||"Not recorded")}</span></td><td><strong>${esc(d.currentProjectName||"No project")}</strong><span>${esc(d.currentLocationLabel||"Not recorded")}</span></td><td><strong>${esc(d.responsibleName||"Unassigned")}</strong><span>${esc(d.responsibilityRoute||"Not recorded")}</span></td><td><strong>${esc(duration(d))}</strong><span>${d.downtimeStartedAt?esc(dateTime(d.downtimeStartedAt)):"No full downtime"}</span></td><td><strong>${esc(u?.note||"No update")}</strong><span>${esc(age(u?.at||d.reportedAt))}</span></td><td><button class="table-open-button" type="button" data-case="${d.id}">Open</button></td>`;body.append(tr);});if(!rows.length){const tr=document.createElement("tr");tr.innerHTML='<td colspan="8" class="defect-empty">No defects match these controls.</td>';body.append(tr);}host.replaceChildren(table);}
function age(value){const ms=Date.now()-new Date(value||0).getTime();if(!Number.isFinite(ms)||ms<0)return "Not recorded";const h=Math.floor(ms/36e5);return h<1?`${Math.max(1,Math.floor(ms/6e4))}m ago`:h<24?`${h}h ago`:`${Math.floor(h/24)}d ago`;}
function renderDonut(rows){const groups={reported:0,awaiting:0,repair:0,rts:0};rows.filter(active).forEach(d=>{const group=donutGroup(d);if(group)groups[group]++;});const total=Object.values(groups).reduce((sum,n)=>sum+n,0),chart=$("repairPositionChart");const order=["reported","awaiting","repair","rts"],colors=["#5d88b4","#d3a042","#d56f35","#4f9b78"],stops=[];let angle=0;order.forEach((key,i)=>{const next=angle+(total?groups[key]/total*360:0);stops.push(`${colors[i]} ${angle}deg ${next}deg`);angle=next;});chart.style.background=total?`conic-gradient(${stops.join(",")})`:"conic-gradient(#d9e0e5 0 360deg)";const centre=chart.querySelector(".repair-donut-centre strong");if(centre)centre.textContent=total;document.querySelectorAll(".repair-legend-row").forEach((row,i)=>{const key=order[i],value=row.querySelector("strong");if(value)value.textContent=groups[key];row.dataset.donut=key;row.classList.toggle("is-selected",donutFilter===key);});}
function updateContext(){const a=asset($("defectAssetSelect").value),c=$("selectedAssetContext");if(!a){c.hidden=true;return;}c.hidden=false;c.querySelector(".asset-reference")?.replaceChildren(document.createTextNode(a.plantReference||a.plantId||a.id));const v=c.querySelectorAll("dd");[a.currentProjectName||"Not recorded",a.currentLocationLabel||"Not recorded",a.ownershipType||a.ownership||"Not recorded",a.supplierName||"Not recorded"].forEach((x,i)=>{if(v[i])v[i].textContent=x;});}
function suggested(){const g=n=>document.querySelector(`input[name="${n}"]:checked`)?.value,p=g("productiveUse"),m=g("mobility"),s=g("safeOperation");const pos=m==="IMMOBILISED"||s==="NO"||p==="NONE"?"OUT_OF_SERVICE":p==="PARTIAL"||s==="RESTRICTED"?"PARTIALLY_AVAILABLE":"AVAILABLE";$("suggestedDefectPosition").querySelector("strong").textContent=label(pos);$("restrictedFunctionField").hidden=!(p==="PARTIAL"||s==="RESTRICTED");return pos;}
function openReport(){$("reportDefectForm").reset();$("defectReportedAt").value=new Date().toISOString().slice(0,16);$("defectDowntimeStartedAt").value=new Date().toISOString().slice(0,16);$("defectReportedBy").textContent=profile?.displayName||profile?.email||"Authenticated user";$("selectedAssetContext").hidden=true;$("reportDefectDialog").showModal();suggested();}
function buildReport(){const a=asset($("defectAssetSelect").value),pos=suggested();if(!a||!clean($("defectDescription").value))throw Error("Select an asset and enter a defect description.");if(!$("confirmDefectPosition").checked)throw Error("Confirm the suggested operational position.");return omit({assetId:a.id,plantId:a.plantId||a.plantReference||a.id,plantReference:a.plantReference||a.plantId||a.id,description:clean($("defectDescription").value),reportedAt:$("defectReportedAt").value,productiveUse:document.querySelector('input[name="productiveUse"]:checked')?.value,mobility:document.querySelector('input[name="mobility"]:checked')?.value,safeOperation:document.querySelector('input[name="safeOperation"]:checked')?.value,workImpact:document.querySelector('input[name="workImpact"]:checked')?.value,restrictedFunction:clean($("restrictedFunction").value)||null,operationalPosition:pos,operationalHold:pos==="OUT_OF_SERVICE",immediateControls:[...document.querySelectorAll(".control-option-grid input:checked")].map(x=>x.value),immediateActionNotes:clean($("defectImmediateNotes").value)||null,caseContactName:clean($("defectCaseContactName").value)||null,caseContactDetail:clean($("defectCaseContactDetail").value)||null,downtimeStartedAt:clean($("defectDowntimeStartedAt").value)||null,responsibilityRoute:clean($("defectResponsibilityRoute").value)||null,currentProjectId:a.currentProjectId||null,currentProjectName:a.currentProjectName||null,currentLocationLabel:a.currentLocationLabel||null,repairSupplier:a.supplierName||null});}
async function save(e){e.preventDefault();if(saving)return;saving=true;try{const d=buildReport(),uid=auth.currentUser?.uid;if(!uid||!reporter(profile))throw Error("You are not authorised to report defects.");await runTransaction(db,async t=>{const p=await t.get(doc(db,"users",uid)),ar=await t.get(doc(db,"plantAssets",d.assetId));if(!p.exists()||!ar.exists()||ar.data().organisationId!==org)throw Error("Asset unavailable.");const a=p.data(),at=new Date().toISOString(),ref=doc(collection(db,"plantDefects")),prev=ar.data();t.set(ref,omit({organisationId:org,...d,status:"REPORTED",statusHistory:[{status:"REPORTED",at,actorUid:uid,actorName:a.displayName||null}],caseUpdates:[{at,actorUid:uid,actorName:a.displayName||null,note:"Defect reported"}],previousAssetState:{status:prev.status,safeToUse:prev.safeToUse,offRoad:prev.offRoad},createdByUid:uid,createdByName:a.displayName||null,createdAt:serverTimestamp(),updatedByUid:uid,updatedByName:a.displayName||null,updatedAt:serverTimestamp()}));if(d.operationalHold)t.update(doc(db,"plantAssets",d.assetId),assetPatch(d,a,uid,serverTimestamp()));});$("reportDefectDialog").close();await reload();}catch(err){$("defectStatus").textContent=err.message;}finally{saving=false;}}
function openCase(d) {
  selectedCase = d;

  const a = asset(d.assetId);
  const drawer = $("repairCaseDrawer");

  $("repairCaseBackdrop").hidden = false;
  drawer.hidden = false;
  drawer.setAttribute("aria-hidden", "false");

  /* ----------------------------------------------------------
     CASE HEADER
  ---------------------------------------------------------- */

  drawer.querySelector(".drawer-plant-id").textContent =
    d.plantReference || d.plantId || "Plant";

  const modelText = [a?.manufacturer, a?.model]
    .filter(Boolean)
    .join(" ");

  const titleLineParts = drawer.querySelectorAll(".drawer-title-line span");

  if (titleLineParts[2]) {
    titleLineParts[2].textContent = modelText || "Plant asset";
  }

  drawer.querySelector("h2").textContent =
    d.description || "Defect repair case";


  /* ----------------------------------------------------------
     CURRENT POSITION
  ---------------------------------------------------------- */

  const positionValues = drawer.querySelectorAll(
    ".position-detail-grid dd"
  );

  const positionData = [
    d.currentProjectName || "Not recorded",
    d.currentLocationLabel || "Not recorded",
    d.reportedByName ||
      d.createdByName ||
      d.caseUpdates?.[0]?.actorName ||
      "Not recorded",
    d.responsibleName || "Unassigned",
    d.repairSupplier ||
      a?.supplierName ||
      "Not recorded",
    d.downtimeStartedAt
      ? dateTime(d.downtimeStartedAt)
      : "Not recorded",
    label(d.responsibilityRoute || "Plant / Transport team"),
    label(d.mobility || "Not recorded"),
  ];

  positionData.forEach((value, index) => {
    if (positionValues[index]) {
      positionValues[index].textContent = value;
    }
  });


  /* ----------------------------------------------------------
     CASE DIARY
  ---------------------------------------------------------- */

  const updates = Array.isArray(d.caseUpdates)
    ? [...d.caseUpdates]
    : [];

  updates.sort((a, b) => {
    const aTime = new Date(a?.at || 0).getTime();
    const bTime = new Date(b?.at || 0).getTime();

    return aTime - bTime;
  });

  const markerClass = update => {
    const status = normal(update?.status || "");

    if (
      status === "CLOSED" ||
      status === "AWAITING_RTS" ||
      status === "REPAIR_COMPLETE"
    ) {
      return "diary-marker--green";
    }

    if (status === "REPAIR_IN_PROGRESS") {
      return "diary-marker--orange";
    }

    if (
      status === "AWAITING_ATTENDANCE" ||
      status === "AWAITING_PARTS" ||
      status === "AWAITING_REPLACEMENT" ||
      status === "REPLACEMENT_REQUESTED"
    ) {
      return "diary-marker--amber";
    }

    if (
      status === "ACKNOWLEDGED"
    ) {
      return "diary-marker--blue";
    }

    return "diary-marker--red";
  };

  const diaryRole = update => {
    if (update?.actorRoleName) {
      return update.actorRoleName;
    }

    if (update?.actorRole) {
      return label(update.actorRole);
    }

    if (
      update?.status === "REPORTED" ||
      update?.note === "Defect reported"
    ) {
      return "Defect report";
    }

    return "";
  };

  const diaryHtml = updates.map(update => {
    const role = diaryRole(update);

    return `
      <article class="diary-entry">

        <div class="diary-marker ${markerClass(update)}"></div>

        <div class="diary-content">

          <div class="diary-meta">

            <strong>
              ${esc(update.actorName || "NORMEX user")}
            </strong>

            ${
              role
                ? `<span>${esc(role)}</span>`
                : ""
            }

            <time>
              ${esc(dateTime(update.at))}
            </time>

          </div>

          <p>
            ${esc(update.note || "Case updated")}
          </p>

        </div>

      </article>
    `;
  }).join("");

  $("repairCaseDiary").innerHTML =
    diaryHtml ||
    `<p class="defect-note">No case updates recorded.</p>`;


  /* ----------------------------------------------------------
     LATEST POSITION
  ---------------------------------------------------------- */

  const latest = updates.length
    ? updates[updates.length - 1]
    : null;

  const latestCard = drawer.querySelector(".latest-position-card");

  if (latestCard) {
    const latestText = latestCard.querySelector("strong");
    const latestMeta = latestCard.querySelector(":scope > span");

    if (latestText) {
      latestText.textContent =
        latest?.note ||
        "Defect reported. Awaiting Plant action.";
    }

    if (latestMeta) {
      latestMeta.textContent = latest
        ? `Updated by ${latest.actorName || "NORMEX user"} · ${age(latest.at)}`
        : "No further update recorded";
    }
  }


  /* ----------------------------------------------------------
     RETURN TO SERVICE
  ---------------------------------------------------------- */

  $("returnToServiceAction").hidden =
    !manage(profile, d) ||
    normal(d.status) !== "AWAITING_RTS";
}
function bind() {
  $("reportDefect").onclick = openReport;
  $("reportDefectForm").onsubmit = save;

  $("reportDefectClose").onclick = () => $("reportDefectDialog").close();
  $("reportDefectCancel").onclick = () => $("reportDefectDialog").close();

  $("defectAssetSelect").onchange = updateContext;

  ["productiveUse", "mobility", "safeOperation", "workImpact"].forEach(name => {
    document.querySelectorAll(`input[name="${name}"]`).forEach(input => {
      input.addEventListener("change", suggested);
    });
  });

  [
    "defectSearch",
    "defectStatusFilter",
    "defectImpactFilter",
    "defectSupplierFilter",
    "defectProjectFilter"
  ].forEach(id => {
    $(id)?.addEventListener(
      id === "defectSearch" ? "input" : "change",
      () => {
        renderRegister();
        renderActive(defects.filter(active));
      }
    );
  });

  document.querySelectorAll("#defectSummary .position-tile").forEach(tile => {
    tile.addEventListener("click", () => {
      summaryFilter =
        summaryFilter === tile.dataset.filter ? "" : tile.dataset.filter;
      render();
    });
  });

  document.querySelectorAll(".repair-legend-row").forEach(row => {
    row.addEventListener("click", () => {
      donutFilter =
        donutFilter === row.dataset.donut ? "" : row.dataset.donut;

      renderRegister();
      renderActive(defects.filter(active));
      renderDonut(defects.filter(active));
    });
  });

  $("repairCaseClose").onclick = closeCase;
  $("repairCaseBackdrop").onclick = closeCase;

  $("addRepairUpdate").onclick = openUpdate;
  $("changeRepairStatus").onclick = openUpdate;
  $("recordRepairFeedback").onclick = openFeedback;
  $("returnToServiceAction").onclick = openRts;

  $("repairUpdateDialog").querySelector("form").onsubmit = saveUpdate;
  $("repairFeedbackDialog").querySelector("form").onsubmit = saveFeedback;
  $("returnToServiceDialog").querySelector("form").onsubmit = confirmRts;

  document.body.addEventListener("click", event => {
    const button = event.target.closest("[data-case]");

    if (!button) return;

    const defect = defects.find(item => item.id === button.dataset.case);

    if (defect) {
      openCase(defect);
    }
  });
}
function closeCase(){$("repairCaseBackdrop").hidden=true;$("repairCaseDrawer").hidden=true;selectedCase=null;}
async function returnService(rts={}){if(!selectedCase)throw Error("No repair case selected.");const uid=auth.currentUser?.uid;if(!uid)throw Error("Session expired.");await runTransaction(db,async t=>{const p=await t.get(doc(db,"users",uid)),r=await t.get(doc(db,"plantDefects",selectedCase.id)),ar=await t.get(doc(db,"plantAssets",selectedCase.assetId));if(!p.exists()||!r.exists()||!ar.exists())throw Error("Case or asset unavailable.");const actor=p.data(),x=r.data();if(actor.organisationId!==org||x.organisationId!==org||ar.data().organisationId!==org||!manage(actor,x))throw Error("Management permission or organisation check failed.");if(normal(x.status)!=="AWAITING_RTS")throw Error("Only a case awaiting return to service can be released.");const all=await t.get(query(collection(db,"plantDefects"),where("organisationId","==",org)));if(all.docs.some(v=>v.id!==selectedCase.id&&v.data().assetId===selectedCase.assetId&&v.data().operationalHold&&normal(v.data().status)!=="CLOSED"))throw Error("Another active restricted defect remains.");const at=new Date().toISOString(),note=clean(rts.note)||"Return to service confirmed",remaining=rts.remainingRestriction==="YES";t.update(doc(db,"plantDefects",selectedCase.id),{status:"CLOSED",rtsNote:note,rtsChecksConfirmed:rts.checksConfirmed,rtsTestOperated:rts.testOperated,rtsRepairComplete:rts.repairComplete,rtsRemainingRestriction:rts.remainingRestriction,confirmedByUid:uid,confirmedByName:actor.displayName||null,confirmedAt:serverTimestamp(),returnToServiceConfirmedAt:serverTimestamp(),caseUpdates:[...(x.caseUpdates||[]),{at,actorUid:uid,actorName:actor.displayName||null,note}],statusHistory:[...(x.statusHistory||[]),{status:"CLOSED",at,actorUid:uid,actorName:actor.displayName||null}]});if(x.operationalHold&&!remaining)t.update(doc(db,"plantAssets",selectedCase.assetId),returnPatch(ar.data(),x.previousAssetState,actor,uid,serverTimestamp()));if(remaining)t.update(doc(db,"plantAssets",selectedCase.assetId),{safeToUse:false,offRoad:true,remainingDefectRestriction:true,updatedByUid:uid,updatedByName:actor.displayName||null,updatedAt:serverTimestamp()});});await reload();closeCase();}async function persistCase(patch){if(!selectedCase)throw Error("Select a repair case first.");const uid=auth.currentUser?.uid;if(!uid)throw Error("Your session has ended.");await runTransaction(db,async transaction=>{const user=await transaction.get(doc(db,"users",uid)),record=await transaction.get(doc(db,"plantDefects",selectedCase.id));if(!user.exists()||!record.exists())throw Error("Case or user profile is unavailable.");const actor=user.data(),defect=record.data();if(actor.organisationId!==org||defect.organisationId!==org||!manage(actor,defect))throw Error("Case management permission required.");if(patch.status&&!valid(defect.status,patch.status))throw Error("Invalid status transition.");const at=new Date().toISOString(),event={at,actorUid:uid,actorName:actor.displayName||null,note:patch.note||"Case updated",status:patch.status||null};transaction.update(record.ref,omit({...patch,caseUpdates:[...(defect.caseUpdates||[]),event],statusHistory:patch.status?[...(defect.statusHistory||[]),{status:patch.status,at,actorUid:uid,actorName:actor.displayName||null}]:defect.statusHistory,updatedAt:serverTimestamp(),updatedByUid:uid,updatedByName:actor.displayName||null}));});await reload();selectedCase=defects.find(x=>x.id===selectedCase.id)||selectedCase;openCase(selectedCase);}function openUpdate(){if(!selectedCase)return;$("repairUpdateNote").value="";$("repairResponsiblePerson").value=selectedCase.responsibleName||"";$("repairExpectedNextAction").value=selectedCase.expectedNextAction||"";$("repairUpdateDialog").showModal();}
function openFeedback(){if(!selectedCase)return;$("repairCompletedAt").value=new Date().toISOString().slice(0,16);$("repairFeedbackDialog").showModal();}
function openRts(){if(!selectedCase)return;$("returnToServiceDialog").showModal();}
async function confirmRts(event){event.preventDefault();try{if(!selectedCase)throw Error("Select a repair case first.");const checks=[...$("returnToServiceDialog").querySelectorAll(".rts-checks input[type=checkbox]")];if(checks.length!==3||checks.some(check=>!check.checked))throw Error("Confirm repair completion, operational checks and test operation before returning Plant to service.");const note=clean($("rtsNote").value);if(!note)throw Error("Add a return-to-service note.");await returnService({repairComplete:true,checksConfirmed:true,testOperated:true,remainingRestriction:$("rtsRemainingRestriction").value,note});$("returnToServiceDialog").close();}catch(error){$("defectStatus").textContent=error.message;console.error("Return to service failed",error);}}
async function saveUpdate(e){e.preventDefault();try{const note=clean($("repairUpdateNote").value);if(!note)throw Error("Add a meaningful case update before saving.");const raw=$("repairUpdateStatus").value,status=raw?raw.toUpperCase().replaceAll(" ","_"):undefined;await persistCase({note,status,expectedNextAction:clean($("repairExpectedNextAction").value)||null,responsibleName:clean($("repairResponsiblePerson").value)||null,responsibleUid:auth.currentUser?.uid||null,responsibilityRoute:clean($("repairRoute").value)||null});$("repairUpdateDialog").close();}catch(error){$("defectStatus").textContent=error.message;console.error("Defect case update failed",error);}}
async function saveFeedback(e){e.preventDefault();try{if(!selectedCase)throw Error("Select a repair case first.");const checked=document.querySelector('input[name="repairOutcome"]:checked'),labels=["FULLY_RESOLVED","PARTIALLY_RESOLVED","ADDITIONAL_FAULT_IDENTIFIED","UNABLE_TO_REPAIR","REPLACEMENT_SUPPLIED"],outcome=checked?labels[[...document.querySelectorAll('input[name="repairOutcome"]')].indexOf(checked)]:"";if(!outcome)throw Error("Select a repair outcome.");await persistCase({note:clean($("repairCompletionNotes").value)||"Repair feedback recorded",repairOutcome:outcome,repairCompletedAt:$("repairCompletedAt").value||null,availabilityAfterRepair:$("repairAvailablePosition").value,completedByUid:auth.currentUser?.uid||null,completedByName:profile?.displayName||null,completionRecordedAt:serverTimestamp(),status:["REPAIR_IN_PROGRESS","AWAITING_REPLACEMENT"].includes(normal(selectedCase.status))?"REPAIR_COMPLETE":undefined});$("repairFeedbackDialog").close();}catch(error){$("defectStatus").textContent=error.message;console.error("Defect repair feedback failed",error);}}function repairCostAccess(p){return manage(p)||p?.permissions?.canViewCommercial===true||p?.permissions?.canManageCommercial===true;}
function money(value){return new Intl.NumberFormat("en-GB",{style:"currency",currency:"GBP"}).format(Number(value||0));}
function costTotal(){const fields=["repairCostCallout","repairCostLabour","repairCostParts","repairCostTransport","repairCostOther"];const total=fields.reduce((sum,id)=>sum+(Number($(id).value)||0),0);$("repairCostTotal").textContent=money(total);return total;}
function openCosts(){if(!selectedCase)return;const costs=selectedCase.repairCosts||{};[["repairCostCallout","callout"],["repairCostLabour","labour"],["repairCostParts","parts"],["repairCostTransport","transport"],["repairCostOther","other"]].forEach(([id,key])=>$(id).value=costs[key]??"");costTotal();$("repairCostDialog").showModal();}
async function saveCosts(event){event.preventDefault();try{if(!selectedCase)throw Error("Select a repair case first.");const uid=auth.currentUser?.uid;if(!uid)throw Error("Your session has ended.");const keys=[["callout","repairCostCallout"],["labour","repairCostLabour"],["parts","repairCostParts"],["transport","repairCostTransport"],["other","repairCostOther"]],costs={};keys.forEach(([key,id])=>{const value=clean($(id).value);if(value!=="")costs[key]=Number(value);});costs.total=costTotal();await runTransaction(db,async transaction=>{const user=await transaction.get(doc(db,"users",uid)),record=await transaction.get(doc(db,"plantDefects",selectedCase.id));if(!user.exists()||!record.exists())throw Error("Case or user profile is unavailable.");const actor=user.data(),defect=record.data();if(actor.organisationId!==org||defect.organisationId!==org||!manage(actor,defect))throw Error("Cost update is not authorised.");transaction.update(record.ref,omit({repairCosts:costs,costUpdatedAt:serverTimestamp(),costUpdatedByUid:uid,costUpdatedByName:actor.displayName||null,updatedAt:serverTimestamp(),updatedByUid:uid,updatedByName:actor.displayName||null}));});$("repairCostDialog").close();await reload();selectedCase=defects.find(d=>d.id===selectedCase.id);if(selectedCase)openCase(selectedCase);}catch(error){$("defectStatus").textContent=error.message;console.error("Defect cost update failed",error);}}function wireSecondaryDialogControls(){["reportDefectDialog","repairUpdateDialog","repairFeedbackDialog","returnToServiceDialog","repairCostDialog"].map($).filter(Boolean).forEach(dialog=>{const close=()=>{if(dialog.open)dialog.close();$("repairCaseClose")?.focus();};dialog.querySelectorAll(".dialog-close, .button-secondary[type=button]").forEach(button=>button.addEventListener("click",close));dialog.addEventListener("cancel",event=>{event.preventDefault();close();});dialog.addEventListener("click",event=>{if(event.target===dialog)close();});});document.querySelector(".drawer-footer .button-success")?.addEventListener("click",openRts);$("addDiaryUpdate")?.addEventListener("click",openUpdate);$("editRepairDetails")?.addEventListener("click",openUpdate);$("updateRepairCosts")?.addEventListener("click",openCosts);$("repairCostForm")?.addEventListener("submit",saveCosts);["repairCostCallout","repairCostLabour","repairCostParts","repairCostTransport","repairCostOther"].forEach(id=>$(id)?.addEventListener("input",costTotal));$("createDefectMovement")?.addEventListener("click",()=>{if(selectedCase)window.location.href=`/modules/contractor/plant/movements/index.html?assetId=${encodeURIComponent(selectedCase.assetId)}&defectId=${encodeURIComponent(selectedCase.id)}`;});document.addEventListener("keydown",event=>{if(event.key==="Escape"&&!document.querySelector("dialog[open]")&&!$("repairCaseDrawer")?.hidden)closeCase();});}
const baseRender=render;
render=function(){baseRender();$("defectCount").textContent=String(defects.length);const total=defects.filter(active).length,heading=document.querySelector(".insight-panel--repair-position .panel-heading-stat strong");if(heading)heading.textContent=String(total);};
function wait(){wireSecondaryDialogControls();if(window.NORMEX_CURRENT_USER)init(window.NORMEX_CURRENT_USER);else window.addEventListener("normex:workspace-ready",e=>init(e.detail.profile),{once:true});}wait();
